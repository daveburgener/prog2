import random
from datetime import datetime
from string import ascii_letters, digits

ALLOWED_FOR_REF_ID = ascii_letters + digits
DATENBANK_FP = "database.csv"

def generate_ref_id():
    return "".join(random.choices(population=ALLOWED_FOR_REF_ID, k=10))

def generate_unique_ref_id(einträge):
    while True:
        ref_id = generate_ref_id()
        if not any([eintrag.split(",")[0] == ref_id for eintrag in einträge]):
            return ref_id

def auslesen():
    with open(DATENBANK_FP, "r") as open_file:
        inhalt = open_file.read()[1:]  # oder nutze .strip
    return inhalt

def todos_laden():
    return [eintrag.split(",") for eintrag in auslesen().splitlines()]

def abspeichern(notiz, datum: str = None, ref_id: str = None):
    einträge = auslesen()
    if not datum:
        datum = datetime.now().strftime("%Y-%m-%d %H:%M")
    if not ref_id:
        ref_id = generate_unique_ref_id(einträge.splitlines())
    neuer_eintrag = f"\n{ref_id},{datum},{notiz}"
    with open(DATENBANK_FP, "a") as open_file:
        open_file.write(neuer_eintrag)

def suchen(text):
    current_content = auslesen()
    search_result = []
    for row in current_content.split("\n"):
        eintrag = row.split(",")
        if text in eintrag[2]:
            search_result.append(eintrag)
    return search_result



