from flask import Flask
from flask import render_template
from flask import request
from werkzeug.utils import redirect
from flask import Flask, flash, request, redirect, url_for

from todoloo.datenbank import abspeichern, auslesen, todos_laden, suchen

app = Flask(__name__)
app.secret_key = 'the random string'


@app.route("/")
@app.route("/index")
def route_index():
    return render_template("index.html", liste=todos_laden(), seitentitel="Start")

@app.route("/add", methods=["GET", "POST"])
def route_add():
    if request.method == "GET":
        return render_template("add.html", seitentitel="Eingabe")

    if request.method == "POST":
        text = request.form['text']
        if not text.strip():
            return redirect("/add")
        abspeichern(text)

        return redirect("/")

@app.route("/search.html", methods=["GET", "POST"])
def route_search():
    if request.method == "GET":
        return render_template("search.html", seitentitel="Suchen")

    if request.method == "POST":
        text = request.form['text']
        ergebnis = suchen(text)
        return render_template("index.html", liste=ergebnis)

@app.route("/delete", methods=["GET"])
def route_delete():
    ref_id = request.args.get("ref_id")
    with open("database.csv", "r") as f:
        content = f.read().splitlines()
    new_content = [eintrag for eintrag in content if not eintrag.startswith(ref_id)]
    with open("database.csv", "w") as f:
        f.write("\n".join(new_content))
    return redirect("/")

if __name__ == "__main__":
    app.run(debug=True, port=5591)
